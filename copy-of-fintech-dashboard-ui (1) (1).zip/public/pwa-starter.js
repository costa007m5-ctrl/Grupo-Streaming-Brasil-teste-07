// This file is no longer in use.
// Service worker registration is now handled by src/index.tsx.
// This file can be safely deleted from your project.
