// This file is no longer in use.
// The Workbox caching logic has been merged into firebase-messaging-sw.js
// to create a single, unified service worker.
// This file can be safely deleted from your project.
